<?php
require_once __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/vendor/phpmailer/phpmailer/src/Exception.php';
require __DIR__ . '/vendor/phpmailer/phpmailer/src/PHPMailer.php';
require __DIR__ . '/vendor/phpmailer/phpmailer/src/SMTP.php';

date_default_timezone_set('Asia/Kolkata');

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function sendMail($to, $subject, $body)
{
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = $_ENV['ML_HOST'];
        $mail->SMTPAuth = true;
        $mail->Username = $_ENV['ML_USER'];
        $mail->Password = $_ENV['ML_PSW'];
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = $_ENV['ML_PORT'];

        $mail->setFrom($_ENV['ML_FROM'], 'Alamgir Mailer');

        foreach ($to as $email) {
            $mail->addBCC($email);
        }

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->AltBody = 'Sorry!, your mail client does not support HTML. Please use a client that supports HTML. Like Gmail, Outlook, etc.';

        if ($mail->send()) {
            return true;
        } else {
            return false;
        }
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}

// function logEmailStatus($status, $email) {
//     $logFile = 'email_status_log.txt';
//     $timestamp = date('Y-m-d H:i:s');
//     $logEntry = "[$timestamp] $status: $email\n";
//     file_put_contents($logFile, $logEntry, FILE_APPEND);
// }


$recipients = ['alamgirsardar66@gmail.com', 'programmeralamgir@gmail.com'];
$subjectMail = 'Test Email From Alamgir Mailer';
$bodyMail = '<h1>Alamgir Mailer</h1> <h2>Test Email</h2> <p>Hi! Thank you for using <b>Alamgir Mailer</b>. Time: ' . date('Y-m-d H:i:s') . '.</p>';

sendMail($recipients, $subjectMail, $bodyMail);